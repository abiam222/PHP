<?php
	/*This is the home page for this site.
	It uses templates to create the layout */

	//Includes the header:
	include('templates/header.html');
	//Leave the PHP secotin to display lots of HTML:
?>
<div id="center">
 </div>
 <?php //Return to PHP
 	include('templates/footer.html');
 	//Include the footer
 ?>